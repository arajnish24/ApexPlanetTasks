// Form Validation
document.getElementById('contactForm').addEventListener('submit', function (e) {
  e.preventDefault();

  let name = document.getElementById('name');
  let email = document.getElementById('email');
  let message = document.getElementById('message');

  let nameError = document.getElementById('nameError');
  let emailError = document.getElementById('emailError');
  let messageError = document.getElementById('messageError');

  nameError.textContent = '';
  emailError.textContent = '';
  messageError.textContent = '';

  let isValid = true;

  if (name.value.trim() === '') {
    nameError.textContent = 'Name is required.';
    isValid = false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.value.trim())) {
    emailError.textContent = 'Enter a valid email address.';
    isValid = false;
  }

  if (message.value.trim().length < 10) {
    messageError.textContent = 'Message must be at least 10 characters.';
    isValid = false;
  }

  if (isValid) {
    alert('Form submitted successfully!');
    document.getElementById('contactForm').reset();
  }
});

// To-Do Functionality
function addTask() {
  const input = document.getElementById('taskInput');
  const taskText = input.value.trim();
  if (taskText === '') return;

  const li = document.createElement('li');
  li.textContent = taskText;

  const removeBtn = document.createElement('button');
  removeBtn.textContent = 'Remove';
  removeBtn.onclick = () => li.remove();

  li.appendChild(removeBtn);
  document.getElementById('taskList').appendChild(li);

  input.value = '';
}
