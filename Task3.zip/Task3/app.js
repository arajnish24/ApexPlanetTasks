const quizData = [
  {
    question: "What does CSS stand for?",
    options: [
      "Computer Style Sheets",
      "Creative Style Sheets",
      "Cascading Style Sheets",
      "Colorful Style Sheets"
    ],
    correct: 2
  },
  {
    question: "Which tag is used to include JavaScript in HTML?",
    options: ["<js>", "<script>", "<javascript>", "<code>"],
    correct: 1
  },
  {
    question: "What does API stand for?",
    options: [
      "Application Programming Interface",
      "App Program Index",
      "Application Protocol Interface",
      "All Purpose Interface"
    ],
    correct: 0
  },
  {
    question: "Which media query is used for small devices?",
    options: [
      "min-width: 1200px",
      "min-device-width: 1024px",
      "max-width: 768px",
      "max-height: 300px"
    ],
    correct: 2
  },
  {
    question: "Which method fetches API data in JS?",
    options: ["request()", "callAPI()", "fetch()", "ajax()"],
    correct: 2
  }
];

let currentQuiz = 0;
let score = 0;

function showQuizQuestion() {
  const q = quizData[currentQuiz];
  const quizContainer = document.getElementById("quiz-container");

  const optionsHtml = q.options
    .map((opt, idx) => `
      <label>
        <input type="radio" name="quizOption" value="${idx}">
        ${opt}
      </label><br>
    `)
    .join("");

  const showSubmit = `
    <button id="submit-btn">Submit</button>
  `;

  quizContainer.innerHTML = `
    <p><strong>Q${currentQuiz + 1}:</strong> ${q.question}</p>
    ${optionsHtml}
    ${showSubmit}
  `;

  // Attach click handler to button again after DOM render
  document.getElementById("submit-btn").addEventListener("click", submitAnswer);
}

function submitAnswer() {
  const selectedOption = document.querySelector('input[name="quizOption"]:checked');
  if (!selectedOption) {
    alert("Please select an answer before submitting.");
    return;
  }

  const selectedAnswer = parseInt(selectedOption.value);
  if (selectedAnswer === quizData[currentQuiz].correct) {
    score++;
  }

  currentQuiz++;

  if (currentQuiz < quizData.length) {
    showQuizQuestion(); // Re-render next question
  } else {
    // Quiz finished
    document.getElementById("quiz-container").innerHTML = `
      <h3>Quiz Completed!</h3>
      <p>Your Score: ${score} / ${quizData.length}</p>
      <button onclick="restartQuiz()">Restart Quiz</button>
    `;
  }
}

function restartQuiz() {
  currentQuiz = 0;
  score = 0;
  showQuizQuestion();
}

// Start quiz
showQuizQuestion();




// ✅ Image Carousel
const images = [
  "https://via.placeholder.com/300x200?text=Image+1",
  "https://via.placeholder.com/300x200?text=Image+2",
  "https://via.placeholder.com/300x200?text=Image+3",
  "https://via.placeholder.com/300x200?text=Image+4"
];

let currentImg = 0;
const imgElement = document.querySelector(".carousel-img");

function showImage(index) {
  imgElement.src = images[index];
}

function prevImage() {
  currentImg = (currentImg - 1 + images.length) % images.length;
  showImage(currentImg);
}

function nextImage() {
  currentImg = (currentImg + 1) % images.length;
  showImage(currentImg);
}

// ✅ Auto Carousel
let autoplay = null;

function startCarousel() {
  autoplay = setInterval(() => {
    nextImage();
  }, 3000);
}

function stopCarousel() {
  clearInterval(autoplay);
}


// ✅ Joke API - Official Joke API
function fetchJoke() {
  fetch("https://official-joke-api.appspot.com/jokes/random")
    .then(res => res.json())
    .then(data => {
      document.getElementById("joke-text").textContent = `${data.setup} - ${data.punchline}`;
    })
    .catch(() => {
      document.getElementById("joke-text").textContent = "Failed to fetch joke.";
    });
}

// ✅ Joke API - Dad Jokes
function fetchDadJoke() {
  fetch("https://icanhazdadjoke.com/", {
    headers: { Accept: "application/json" }
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("joke-text").textContent = data.joke;
    })
    .catch(() => {
      document.getElementById("joke-text").textContent = "Failed to fetch dad joke.";
    });
}
