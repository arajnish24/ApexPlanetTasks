/******************************* Toggle Icon Navbar *************************************/
let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

menuIcon.onclick = () => {
    menuIcon.classList.toggle('bx-x');
    navbar.classList.toggle('active');
};

/******************************* Scroll Section Active Link *************************************/
let section = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');

window.onscroll = () => {
    section.forEach(sec => {
        let top = window.scrollY;
        let offset = sec.offsetTop - 150;
        let height = sec.offsetHeight;
        let id = sec.getAttribute('id');

        if(top >= offset && top < offset + height ){
            navLinks.forEach(links => {
                links.classList.remove('active');
                document.querySelector('header nav a[href*=' + id + ']').classList.add('active');
            });
        };
    });

    /***************************** Sticky Navbar ****************************/
    let header = document.querySelector('header');

    header.classList.toggle('sticky', window.scrollY > 100);

    /************** Remove toggle icon and navbar when click navbar link ( Scroll )  *********************/
    menuIcon.classList.remove('bx-x');
    navbar.classList.remove('active');
};

/***************************** Scroll Reveal ****************************/
ScrollReveal({ 
    // reset: true,
    distance: '80px',
    duration: 2000,
    delay: 200
});

ScrollReveal().reveal('.home-content, .heading', { origin: 'top' });
ScrollReveal().reveal('.home-img, .services-container, .portfolio-box, .contact form',
    { origin: 'bottom' });
ScrollReveal().reveal('.home-content h1, .about-img', { origin: 'left' });
ScrollReveal().reveal('.home-content p, .about-content', { origin: 'Right' });

/***************************** Typed JS ****************************/
const typed = new Typed('.multiple-text', {
    strings: ['Fronten Developer', 'YouTuber', 'Blogger'],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})

// Force CV Download
// document.querySelector('.btn.download-cv')?.addEventListener('click', function (e) {
//     e.preventDefault();
//     const link = document.createElement('a');
//     link.href = "D:\Code\Portfolio\files\CV.pdf"; // Path to your CV
//     link.download = 'Anmol_Rajnish_CV.pdf';
//     document.body.appendChild(link);
//     link.click();
//     document.body.removeChild(link);
// });


// Project Modal Script
const modal = document.getElementById('project-modal');
const closeBtn = document.querySelector('.close-btn');
const modalTitle = document.getElementById('modal-title');
const modalDescription = document.getElementById('modal-description');
const modalSlider = document.getElementById('modal-slider');
const modalCode = document.getElementById('modal-code');
const modalMore = document.getElementById('modal-more');

let currentSlide = 0;

document.querySelectorAll('.view-project').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        const projectBox = this.closest('.portfolio-box');
        
        modalTitle.textContent = projectBox.dataset.title;
        modalDescription.textContent = projectBox.dataset.description;
        modalCode.innerHTML = projectBox.dataset.code;
        modalMore.textContent = projectBox.dataset.more;

        // Create image slides
        const images = projectBox.dataset.images.split(',');
        modalSlider.innerHTML = images.map(src => `<img src="${src.trim()}" alt="">`).join('');
        currentSlide = 0;
        updateSlider();

        modal.style.display = 'block';
    });
});

// Slider navigation
document.querySelector('.prev').addEventListener('click', () => {
    const totalSlides = modalSlider.children.length;
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    updateSlider();
});

document.querySelector('.next').addEventListener('click', () => {
    const totalSlides = modalSlider.children.length;
    currentSlide = (currentSlide + 1) % totalSlides;
    updateSlider();
});

function updateSlider() {
    modalSlider.style.transform = `translateX(-${currentSlide * 100}%)`;
}

// Close modal
closeBtn.addEventListener('click', () => modal.style.display = 'none');
window.addEventListener('click', (e) => {
    if (e.target === modal) modal.style.display = 'none';
});

