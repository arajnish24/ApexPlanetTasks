const products = [
  { name: 'Laptop', category: 'Electronics', price: 800, rating: 4.5 },
  { name: 'Shirt', category: 'Clothing', price: 30, rating: 4.0 },
  { name: 'Headphones', category: 'Electronics', price: 100, rating: 4.2 },
  { name: 'Jeans', category: 'Clothing', price: 50, rating: 4.3 }
];

function renderProducts(list) {
  const ul = document.getElementById('productList');
  ul.innerHTML = '';
  list.forEach(p => {
    const li = document.createElement('li');
    li.textContent = `${p.name} - $${p.price} - Rating: ${p.rating}`;
    ul.appendChild(li);
  });
}

function filterAndSort() {
  const category = document.getElementById('categoryFilter').value;
  const sort = document.getElementById('sortOption').value;
  let filtered = products.filter(p => category === 'All' || p.category === category);
  filtered.sort((a, b) => a[sort] - b[sort]);
  renderProducts(filtered);
}

document.getElementById('categoryFilter').addEventListener('change', filterAndSort);
document.getElementById('sortOption').addEventListener('change', filterAndSort);

filterAndSort();
